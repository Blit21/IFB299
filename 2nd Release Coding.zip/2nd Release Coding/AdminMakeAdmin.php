<?php
   include("Config.php");
   if($_SERVER["REQUEST_METHOD"] == "POST") {
      // username and password sent from form 
      
    $firstname = mysqli_real_escape_string($db,$_POST['firstname']);
    $lastname = mysqli_real_escape_string($db,$_POST['lastname']);
    $username = mysqli_real_escape_string($db,$_POST['username']);
    $password = mysqli_real_escape_string($db,$_POST['password']);
    $cpassword = mysqli_real_escape_string($db,$_POST['cpassword']);
  
    $email = mysqli_real_escape_string($db,$_POST['email']);
    $mobilenum = mysqli_real_escape_string($db,$_POST['mobile']);
    $homenum = mysqli_real_escape_string($db,$_POST['home']);
    
    if($cpassword==$password && $cpassword!=""){
        
        $sql="SELECT * from Accounts WHERE username='$username' OR Email='$email' OR MobileNumber='$mobilenum' OR HomeNumber='$homenum'";
        $result = mysqli_query($db,$sql) or die(mysqli_error($db));
        
        if($result){
            $count = mysqli_num_rows($result);
            if($count==0){

                $insertsql = "INSERT INTO Accounts (user_id,FirstName,LastName,username,password,Email,MobileNumber,HomeNumber,Permission) VALUES (NULL, '$firstname','$lastname','$username','$password','$email','$mobilenum','$homenum','Admin');";

                $insertresult = mysqli_query($db,$insertsql) or die(mysqli_error($db));
                
                if($insertresult){
                    header("Location: http://daveproperties.comeze.com/Profile.php");
                    exit();
                }
            }else{
                $sql="SELECT * from Accounts WHERE username='$username'";
                $result = mysqli_query($db,$sql) or die(mysqli_error($db));
                if ($result){
                        $str1="Username ";
                } else{
                    $str1="";
                }

                $sql="SELECT * from Accounts WHERE Email='$email'";
                $result = mysqli_query($db,$sql) or die(mysqli_error($db));
                if ($result){
                    $str2="Email ";
                } else{
                    $str2="";
                }

                $sql="SELECT * from Accounts WHERE MobileNumber ='$mobilenum'";
                $result = mysqli_query($db,$sql) or die(mysqli_error($db));
                if ($result){
                    $str3="Mobile# ";
                } else{
                    $str3="";
                }

                $sql="SELECT * from Accounts WHERE HomeNumber='$homenum'";
                $result = mysqli_query($db,$sql) or die(mysqli_error($db));
                if ($result){
                    $str4="Home# ";
                } else{
                    $str4="";
                }
                
                echo "Please change the following as they are already in use:" . $str1 . $str2 . $str3 . $str4;
            }
        }
        
    }else{
        echo 'Your passwords did not match';
    }

}
?>
<!DOCTYPE html>
<html>
    
<head>
<style> 
    
    .positioning{
        display:block;
        border: 1px solid black;
        width:370px;
        min-width: 370px;
        padding:20px;   
        float:inherit;
        margin:100px auto; 
    }
    
    input[type=password],input[type=username]{
        width:200px;
    }

    input[type=submit],input[type=button]{
        width:370px;
    }
    
</style>  
</head> 
    
<body bgcolor="#E6E6FA">
<?php
         include('session.php');
         if($row['Permission']=='Admin'){
         
         }else{
              header("Location: http://daveproperties.comeze.com/homepage.php");
              exit();
         }
    ?>
    <div class="positioning">
        <form action="" method="POST">
            <table class="table">
                <col width="150" >
                <col width="200">
                <tr>
                    <td>First Name:</td>
                    <td><input class="UserInput" type="username"  name="firstname" /></td>
                </tr>
                <tr>
                    <td>Last Name:</td>
                    <td><input class="UserInput" type="username"  name="lastname" /></td>
                </tr>
                <tr>
                    <td>Username:</td>
                    <td><input class="UserInput" type="username"  name="username" /></td>
                </tr>
                <tr>
                    <td>Password</td>
                    <td><input class="UserInput" type="password"  name="password" /></td>
                </tr>
                <tr>
                    <td>Confirm Password:</td>
                    <td><input class="UserInput" type="password"  name="cpassword" /></td>
                </tr>
                <tr>
                    <td>Email:</td>
                    <td><input class="UserInput" type="username"  name="email" /></td>
                </tr>
                <tr>
                    <td>Mobile #:</td>
                    <td><input class="UserInput" type="username"  name="mobile"/></td>
                </tr>
                <tr>
                    <td>Home #:</td>
                    <td><input class="UserInput" type="username"  name="home"/></td>
                </tr>
            </table>
            <label>Please fill out ALL the details</label>
            <input type="Submit" value="Complete Admin Account">
        </form>
        <form action="http://daveproperties.comeze.com/Profile.php">
            <input type="Submit" value="Return to Profile Page">
        </form>


    </div>
</body>
    
</html>