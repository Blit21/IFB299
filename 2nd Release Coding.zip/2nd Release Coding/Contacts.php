<!DOCTYPE html>
<html>

<head>


<style>

ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    background-color: #789;
    position: fixed;
    height: 97%;
    overflow: auto;
    border: 1px solid #000;
}

li a {
    display: block;
    color: #000;
    text-decoration: none;
	padding-top: 20px;
	padding-bottom: 20px;
}

li a:hover {
    background-color: #784;
    color: white;
}

li {
    text-align:center;
    border-bottom: 1px solid #000;
    display: block;
    color: #000;
    text-decoration: none;
	width: 100;
}

li:last-child {
    border-bottom: none;
}

.NavButtons{
	height:58px;

}

.infobars{
	padding-top: 20px;
	padding-bottom: 20px;
    background-color: #789;
}

.ProfilePicture{
	width:80px;
	height:75px;
	border:1px solid black;
}

.InfoColumn{
    float:left;
    margin-left: 140px;
    width:550px;
}

.ContactBox{
    height: 175px;
    min-width:500px;
    max-width:600px;
}

.ContactTextBox{
    float:left;
    text-align: left;
    padding-left:10px;
    width:400px;
    border:1px solid black;
    min-height: 100px;
}

.info{
    line-height: 140%;
}

.AdvertColumn{
    float: left;
    margin-left: 20px;
    max-width: 150px;
}

.picture{
    float:left;
    width:140px;
    height:175px;
    border:1px solid black;
}



</style>
</head>

<body bgcolor="#E6E6FA">
<?php
         include('session.php');
         if($row['Permission']=='Tenant'||$row['Permission']=='Staff'||$row['Permission']=='Admin'){
         
         }else{
              header("Location: http://daveproperties.comeze.com/LoginPage.php");
              exit();
         }
    ?>

  <div class="Navigation">
        <ul>
            <li style="padding:20px 20px;">
                <img src="https://daveproperties.000webhostapp.com/default-profile-pic.jpg" class="ProfilePicture">
                <a href="http://daveproperties.comeze.com/Profile.php" style="height:15px;border:1px solid black; padding-bottom:3px;">Edit Profile</a>
            </li>
            <?php
                include('session.php');
                
                echo '<li class="infobars"> Username:'. $row['username'].'</li>
                <li class="infobars"> User Type:'. $row['Permission'].'</li>';
               
               
            ?>
            
            <li style="height:20px;background-color:#787"></li>
            <li class="NavButtons"><a class="NavButtonLink" href="Signout.php">Sign in/out</a></li>

            <li class="NavButtons"><a class="NavButtonLink" href="http://daveproperties.comeze.com/homepage.php">Homepage</a></li>
            
            <li class="NavButtons"><a class="NavButtonLink" href="http://daveproperties.comeze.com/Contacts.php">Contacts</a></li>
            <li class="NavButtons"><a class="NavButtonLink" href="http://daveproperties.comeze.com/Properties.php">Properties</a></li>
            <li class="NavButtons"><a class="NavButtonLink" href="http://daveproperties.comeze.com/About Us.php">About us</a></li>
            
            <li style="height:20px;background-color:#787"></li>

           
        </ul>
    </div>

    <div style="max-width:600px;">
        <div class="InfoColumn">
                <?php
                include('session.php');
                $Staffsql="SELECT * FROM staffinformation";
                $result=mysqli_query($db,$Staffsql) or die(mysqli_error($db));
                
                
                
                echo'<h2 style="margin-left:20px;">Staff</h2>';
                
                while($Staffrow=mysqli_fetch_assoc($result)){
                    echo '<table class="ContactBox" ><tr><td><img class="picture" src="'.$Staffrow['Picture'].'" alt="first staffmember"></td><td><div class="ContactTextBox"><h3>'. $Staffrow['Name'].'</h3>';
                    echo '<p class="info">Position: ' .$Staffrow['Role'].'<br>';
                    echo 'Works At: ' .$Staffrow['Workplace'].'<br>';
                    echo 'Email: ' .$Staffrow['Email'].'<br>';
                    echo 'Mobile #: ' .$Staffrow['CellPhoneNum'].'<br>';
                    echo 'Home #: '. $Staffrow['House'].'</p>';
                    echo '</div></td></tr></table>';
                }

                if($row['Permission']=='Admin'||$row['Permission']=='Staff'){
                    $Ownersql="SELECT * FROM ownerinformation";
                    $ownerresult=mysqli_query($db,$Ownersql) or die(mysqli_error($db));
                
                    
                
                    echo'<h2 style="margin-left:20px;">Home Owners</h2>';

                    while($ownerrow=mysqli_fetch_assoc($ownerresult)){
                    echo '<table class="ContactBox" ><tr><td><img class="picture" src="'.$ownerrow['Picture'].'" alt="first staffmember"></td><td><div class="ContactTextBox"><h3>'. $ownerrow['Name'].'</h3>';
                    echo '<p class="info">Owns House: ' .$ownerrow['Own House'].'<br>';
                    echo 'Mobile #: ' .$ownerrow['Cell Phone#'].'<br>';
                    echo 'Experience:' .$ownerrow['Time rent'].'</p>';
                    echo '</div></td></tr></table>';
                    }

                    $Adminsql="SELECT * FROM administration";
                    $Adminresult=mysqli_query($db,$Adminsql) or die(mysqli_error($db));
                
                    $Adminrow=mysqli_fetch_array($Adminresult);
                
                    echo'<h2 style="margin-left:20px;">Administration</h2>';

                  
                    echo '<table class="ContactBox" ><tr><td><img class="picture" src="https://daveproperties.000webhostapp.com/default-profile-pic.jpg" alt="first staffmember"></td><td><div class="ContactTextBox"><h3>'. $Adminrow['Name'].'</h3>';
                    echo '<p class="info">Mobile #: ' .$Adminrow['PhoneNum'].'</p>';             
                    echo '</div></td></tr></table>';
                    
                    $Davesql="SELECT * FROM SiteOwner";
                    $Daveresult=mysqli_query($db,$Davesql) or die(mysqli_error($db));
                
                    $Daverow=mysqli_fetch_array($Daveresult);
                
                    echo'<h2 style="margin-left:20px;">Site Owner</h2>';

                    
                    echo '<table class="ContactBox" ><tr><td><img class="picture" src="https://daveproperties.000webhostapp.com/default-profile-pic.jpg" alt="first staffmember"></td><td><div class="ContactTextBox"><h3>'. $Daverow['FirstName'].' '. $Daverow['LastName']. '</h3>';
                    echo '<p class="info">Email: ' .$Daverow['email'].'</p>';             
                    echo '</div></td></tr></table>';
                    
                   

                }

            ?>

        </div>

    </div>

</body>

</html>

<!--Joshua Moratalla "table the contact info"-->