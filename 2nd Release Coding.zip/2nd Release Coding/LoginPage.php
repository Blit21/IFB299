<?php
    include("Config.php");
    session_start();
   
    if($_SERVER["REQUEST_METHOD"] == "POST") {
        // username and password sent from form 
      
        $username = mysqli_real_escape_string($db,$_POST['username']);
        $password = mysqli_real_escape_string($db,$_POST['password']); 
      
        $sql = "SELECT user_id,Permission FROM Accounts WHERE username = '$username' and password = '$password'";
        $result = mysqli_query($db,$sql) or die(mysqli_error($db));
        $row = mysqli_fetch_array($result);

      
        if($result){
        $count = mysqli_num_rows($result);
		
        if($count == 1) {
            $_SESSION['login_user'] = $username;       
            header("Location: http://daveproperties.comeze.com/homepage.php");
            exit();
            
        }else {
            echo"Your Login Name or Password is invalid";
        }
    }else{
        die(mysql_error());
    }
       
        
   }
?>

<!DOCTYPE html>
<html>
<head>
<style>

    .positioning{

        display:block;
            border: 1px solid black;
            width:260px;
            min-width: 260px;
            padding:20px;

            float:inherit;
            margin:200px auto;
    }

    .User
input{
        float:left;
    }

    input[type=username],input[type=password]{
        width:175px;
    }
    
    input[type=submit],input[type=button]{
        width:255px;
    }



</style>
</head>
<body bgcolor="#E6E6FA">


<div class="positioning">
    
        <form action="" method="POST"> 
            <table>
                <tr>
                    <td>Username:</td>
                    <td><input class="UserInput" type="username" name="username" placeholder="Enter Username here..."/></td>
                </tr>
                
                <tr>
                    <td>Password:</td>
                    <td><input class="UserInput" type="password"  name="password" placeholder="Enter Password here..."/></td>
                </tr>
            </table>
            <input type="Submit" value="Login"/>        
        </form>
        <form action="http://daveproperties.comeze.com/Register.php">
            <input type="Submit" value="Register as new user?"/>
        </form>
         <form action="https://www.gumtree.com.au/s-ad/petrie/business-for-sale/dave-properties/1149588187">
            <input type="Submit" value="Head to Gumtree"/>
        </form>
        
</div>

</body>
</html> 

<!--Joshua Moratalla-->