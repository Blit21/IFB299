<!DOCTYPE html>
<html>
<head>
<style>


</style>
    
</head>

<body bgcolor="#E6E6FA">
    <?php
         include('session.php');
         if($row['Permission']=='Tenant'||$row['Permission']=='Staff'||$row['Permission']=='Admin'){
         
         }else{
              header("Location: http://daveproperties.comeze.com/LoginPage.php");
              exit();
         }
    ?>
                
<table>

        <tr>
            <th>Details </th>
            <th>Current information </th>
            
        </tr>

<?php
   include('session.php');
   $declareuser= $row['username'];
    $sql= "SELECT FirstName,LastName,username,password,Email,MobileNumber,HomeNumber FROM Accounts WHERE username = '$declareuser'";
    $result=mysqli_query($db,$sql) or die(mysqli_error($db));
    $personalinfo = mysqli_fetch_array($result);


      echo ' <tr>
            <td>First Name :</td>
            <td>'.$personalinfo['FirstName'].'</td>
        </tr>';
echo ' <tr>
            <td>LastName :</td>
            <td>'.$personalinfo['LastName'].'</td>
        </tr>';
echo ' <tr>
            <td>Username :</td>
            <td>'.$personalinfo['username'].'</td>
        </tr>';
echo ' <tr>
            <td>Password :</td>
            <td>'.$personalinfo['password'].'</td>
        </tr>';
echo ' <tr>
            <td>Email :</td>
            <td>'.$personalinfo['Email'].'</td>
        </tr>';
echo ' <tr>
            <td>Mobile Number :</td>
            <td>'.$personalinfo['MobileNumber'].'</td>
        </tr>';
echo ' <tr>
            <td>Home Number:</td>
            <td>'.$personalinfo['HomeNumber'].'</td>
        </tr>';
?>  
    
    </table>
        <form action="http://daveproperties.comeze.com/UpdateProfile.php">
             <input style="float:left;" type="Submit" value="Edit Details"/>
        </form>
        <form action="http://daveproperties.comeze.com/homepage.php">
            <input type="Submit" value="Return to Homepage"/>
        </form>


   <?php
     include('session.php');

     

     if ($row['Permission']=='Staff'){
         echo'<h3>Assigned Tenants</h3>';
         echo'<table>';
         $sql= "SELECT FirstName,LastName,username,password,Email,MobileNumber,HomeNumber FROM Accounts WHERE username = '$declareuser'";
        $result=mysqli_query($db,$sql) or die(mysqli_error($db));
        $row= mysqli_fetch_array($result);
         
         $Staffmember =$row['FirstName'] . " " . $row['LastName'];
         
         $firstsql="SELECT CurrentHouseTenant FROM houseinformation WHERE StaffMember='$Staffmember'";

         $StaffToTenant=mysqli_query($db,$firstsql) or die(mysqli_error($db));

         $Retrieval=mysqli_fetch_array($StaffToTenant);
         
         $TenantInfo=$Retrieval['CurrentHouseTenant'];
         $secondsql="SELECT Name,Occupies,PaymentFrequency,Email,MobileNumber,LeaseDuration,PaymentStartDate FROM tenantinformation WHERE Name='$TenantInfo'";

         $Retrievalquery=mysqli_query($db,$secondsql) or die(mysqli_error($db));
         $Retrievalcount=mysqli_num_rows($Retrievalquery);
         if($Retrievalcount!=0){
         while( $Retrievalrow=mysqli_fetch_assoc($Retrievalquery)){
                echo'<tr><td> Name:</td><td>'.$Retrievalrow['Name'].'</td></tr>';
                echo'<tr><td> Occupies:</td><td>'.$Retrievalrow['Occupies'].'</td></tr>';
                echo'<tr><td> Payment Frequency:</td><td>'.$Retrievalrow['PaymentFrequency'].'</td></tr>';
                echo'<tr><td> Email;</td><td>'.$Retrievalrow['Email'].'</td></tr>';
                echo'<tr><td> Mobile Number:</td><td>'.$Retrievalrow['MobileNumber'].'</td></tr>';
                echo'<tr><td> Lease Duration:</td><td>'.$Retrievalrow['LeaseDuration'].'</td></tr>';
                echo'<tr><td> Payment Start Date:</td><td>'.$Retrievalrow['PaymentStartDate'].'</td></tr>';
  
         }
         echo'</table>';
        }else{
 echo'You do not have any assigned tenants';
}
     }elseif($row['Permission']=='Admin'){
          echo'<form action="http://daveproperties.comeze.com/AdminMakeStaff.php">
            <input type="Submit" value="Make Staff Account"/>
          </form>';
          echo'<form action="http://daveproperties.comeze.com/AdminMakeAdmin.php">
            <input type="Submit" value="Make Admin Account"/>
          </form>';
     }
    
?>
           
        
    
</body>
</html>
<!--Joshua Moratalla-->