<!DOCTYPE html>
<html>
<head>
<style>

ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    background-color: #789;
    position: fixed;
    height: 97%;
    border: 1px solid #000; 
    overflow: auto;
}

li a {
    display: block;
    color: #000;
    text-decoration: none;
}

li a:hover {
    background-color: #784;
    color: white;
}
    
li {
    text-align: center;
    border-bottom: 1px solid #000;
    display: block;
    color: #000;
    text-decoration: none;
	max-width: 120px;
}


.NavButtons{
	height:58px;
	background-color: #789;
}

.NavButtonLink{
    padding-top: 20px;
	padding-bottom: 20px;
}

.infobars{
	padding-top: 20px;
	padding-bottom: 20px;
}

.ProfilePicture{
	width:80px;
	height:75px; 
	border:1px solid black;
}

.MainColumn{
    float:left;
    margin-left: 140px;
    width:700px;
    padding:10px;
}

.SearchArea{
    height:0px;
    padding: 10px;
}
    
.IndividualResult{
    border:1px solid black;
    min-width:600px;
    height:150px;
    margin-bottom: 10px;
}



.SearchPicture{
    float:left;
    width:150px;
    height:115px;
    border:1px solid black;    
}
    
.info{
    float:left; 
    text-align: left; 
    padding-left:10px;
}

.results{
    margin-top: 20px;
}

.picture{
    float:left;
    height:116px;
    width:150px;
}
</style>
</head>
    
<body bgcolor="#E6E6FA">
     <?php
         include('session.php');
         if($row['Permission']=='Tenant'||$row['Permission']=='Staff'||$row['Permission']=='Admin'){
         
         }else{
              header("Location: http://daveproperties.comeze.com/LoginPage.php");
              exit();
         }
    ?>
    <div class="Navigation">
        <ul>
            <li style="padding:20px 20px;">
                <img src="https://daveproperties.000webhostapp.com/default-profile-pic.jpg" class="ProfilePicture">
                <a href="http://daveproperties.comeze.com/Profile.php" style="height:15px;border:1px solid black; padding-bottom:3px;">Edit Profile</a>
            </li>
            <?php
                include('session.php');
                
                echo '<li class="infobars"> Username:'. $row['username'].'</li>
                <li class="infobars"> User Type:'. $row['Permission'].'</li>';
               
               
            ?>
            
            <li style="height:20px;background-color:#787"></li>
            <li class="NavButtons"><a class="NavButtonLink" href="Signout.php">Sign in/out</a></li>

            <li class="NavButtons"><a class="NavButtonLink" href="http://daveproperties.comeze.com/homepage.php">Homepage</a></li>
            
            <li class="NavButtons"><a class="NavButtonLink" href="http://daveproperties.comeze.com/Contacts.php">Contacts</a></li>
            <li class="NavButtons"><a class="NavButtonLink" href="http://daveproperties.comeze.com/Properties.php">Properties</a></li>
            <li class="NavButtons"><a class="NavButtonLink" href="http://daveproperties.comeze.com/About Us.php">About us</a></li>
            
            <li style="height:20px;background-color:#787"></li>

           
        </ul>
    </div>
    
    <img src="house-for-rent.jpg" alt="homepage image" style="border:1px solid black;margin-left:140px;width:750px;height:500px">
    
    
    <div class="MainColumn" style="border:1px solid black;min-width:600px;max-width:700px;">
        <div style="min-width:700">
            <h2 style="margin-left:20px;">All Homes</h2>
          
        
        <div class="results">
            <ol>
                    <?php 
                         include('session.php');
                        $sql="SELECT * FROM houseinformation ";
                        $result= mysqli_query($db,$sql) or die(mysqli_error($db));
                        
                        if($result){
                            $count=mysqli_num_rows($result);
                            if($count>0){
                                while($row=mysqli_fetch_assoc($result)){

                                    echo '<li class="IndividualResult">
                                        <img src="'.$row['Picture'].'"alt="advert image" class="picture">
                                        <div class="info">
                                            <table>
                                                <col width="110px">
                                                <col width="300px">';

                                    echo '      <tr><td>Location:</td><td>'.$row['Address'].$row['Suburb'].'</td></tr>';
                                                
                                    echo '      <tr><td>Property Type:</td><td>'.$row['PropertyType'].'</td></tr>';

                                    echo '      <tr><td>Rent:</td><td>'.$row['Rent'].'</td></tr>';
                                                
                                    echo '      <tr><td>Utilities:</td><td>'.$row['Other'].'</td></tr>';
                                    echo '      </table>
                                            
                                        </div>
                                    </li>';

                                }
                            
                            }else{
                             echo " There were no matches to the following";
                            }
                        
                        }else{
                              echo " Error occurred";
                        }
                    
                ?>
            </ol>

        </div>
    </div>
        

        
    </div>
    
</body>
</html>

<!--Joshua Moratalla-->