<?php
include('session.php');
   if($_SERVER["REQUEST_METHOD"] == "POST") {
   
       $UDfirstname=mysqli_real_escape_string($db,$_POST['firstname']);
       $UDlastname=mysqli_real_escape_string($db,$_POST['lastname']);
       $UDusername=mysqli_real_escape_string($db,$_POST['username']);
       $UDpassword=mysqli_real_escape_string($db,$_POST['password']);
       $UDcpassword=mysqli_real_escape_string($db,$_POST['cpassword']);
       $UDemail=mysqli_real_escape_string($db,$_POST['email']);
       $UDmobile=mysqli_real_escape_string($db,$_POST['mobile']);
       $UDhome=mysqli_real_escape_string($db,$_POST['home']);

       if($UDusername!=""||$UDpassword!=""||$UDemail!=""||$UDmobile!=""||$UDhome!=""){
           if($UDpassword==$UDcpassword ){

                $sql="SELECT * from Accounts WHERE username='$UDusername' OR Email='$UDemail' OR MobileNumber='$UDmobile' OR HomeNumber='$UDhome'";
                $result = mysqli_query($db,$sql) or die(mysqli_error($db));

                if($result){
                    $count = mysqli_num_rows($result);
                    if($count==1 && $row['user_id']==$count['user_id']){
                        $id=$row['user_id'];

                        $updatesql = "UPDATE Accounts SET FirstName=$UDfirstname,LastName='$UDlastname',username='$UDusername',password='$UDpassword',Email='$UDemail',MobileNumber='$UDmobile',HomeNumber='$UDhome' WHERE user_id='$id'";
                        
                       

                        $updateresult = mysqli_query($db,$updatesql) or die(mysqli_error($db));

                        if($updateresult){
                            header("Location: http://daveproperties.comeze.com/Profile.php");
                            exit();
                        }else{
                             echo 'Error occured, please try again';
                        }

                    }else{
                        $sql="SELECT * from Accounts WHERE username='$UDusername'";
                        $result = mysqli_query($db,$sql) or die(mysqli_error($db));
                        if ($result){
                                $str1="Username ";
                        } else{
                            $str1="";
                        }

                        $sql="SELECT * from Accounts WHERE Email='$UDemail'";
                        $result = mysqli_query($db,$sql) or die(mysqli_error($db));
                        if ($result){
                            $str2="Email ";
                        } else{
                            $str2="";
                        }

                        $sql="SELECT * from Accounts WHERE MobileNumber ='$UDmobile'";
                        $result = mysqli_query($db,$sql) or die(mysqli_error($db));
                        if ($result){
                            $str3="Mobile# ";
                        } else{
                            $str3="";
                        }

                        $sql="SELECT * from Accounts WHERE HomeNumber='$UDhome'";
                        $result = mysqli_query($db,$sql) or die(mysqli_error($db));
                        if ($result){
                            $str4="Home# ";
                        } else{
                            $str4="";
                        }

                        echo "Please change the following as they are already in use:" . $str1 . $str2 . $str3 . $str4;
                    }
                }

            }else{
                echo 'Your passwords did not match';
            }
    

    }else{
        echo 'Have atleast your username,password,email,mobile number and home number filled in';
    }
  }
?>




<!DOCTYPE html>
<html>
<head>
<style>


</style>
    
</head>

<body bgcolor="#E6E6FA">
    <?php
         include('session.php');
         if($row['Permission']=='Tenant'||$row['Permission']=='Staff'||$row['Permission']=='Admin'){
         
         }else{
              header("Location: http://daveproperties.comeze.com/LoginPage.php");
              exit();
         }
    ?>
          
    <form action="" method="POST">
        <table>
            <tr>
                <th>Details</th>
                <th>Current Details:</th>
                <th>New/Same Details</th>
           </tr>

    <?php
        include('session.php');
        $id= $row['user_id'];
        $sql= "SELECT FirstName,LastName,username,password,Email,MobileNumber,HomeNumber FROM Accounts WHERE user_id = '$id'";
        $result=mysqli_query($db,$sql) or die(mysqli_error($db));
        $row = mysqli_fetch_array($result);

    echo ' <tr>
                <td>First Name :</td>
                <td>'.$row['FirstName'].'</td>
                <td><input class="UserInput" type="text" name="firstname" /></td>
    </tr>';
    echo ' <tr>
                <td>LastName :</td>
                <td>'.$row['LastName'].'</td>
                <td><input class="UserInput" type="username" name="lastname" /></td>
    </tr>';
    echo ' <tr>
                <td>Username :</td>
                <td>'.$row['username'].'</td>
                <td><input class="UserInput" type="username" name="username" placeholder="MUST BE FILLED" /></td>
        </tr>';
    echo ' <tr>
                <td>Password :</td>
                <td>'.$row['password'].'</td>
                <td><input class="UserInput" type="password" name="password"placeholder="MUST BE FILLED"/></td>
        </tr>';
    echo ' <tr>
                <td>Confirm Password:</td>
                <td></td>
                <td><input class="UserInput" type="password" name="cpassword" placeholder="MUST BE FILLED"/></td>
        </tr>';
    echo ' <tr>
                <td>Email :</td>
                <td>'.$row['Email'].'</td>
                <td><input class="UserInput" type="username" name="email" placeholder="MUST BE FILLED"/></td>
        </tr>';
    echo ' <tr>
                <td>Mobile Number :</td>
                <td>'.$row['MobileNumber'].'</td>
                <td><input class="UserInput" type="username" name="mobile" placeholder="MUST BE FILLED"/></td>
        </tr>';
    echo ' <tr>
                <td>Home Number:</td>
                <td>'.$row['HomeNumber'].'</td>
                <td><input class="UserInput" type="username" name="home" placeholder="MUST BE FILLED"/></td>
    </tr>';
    ?>  
    
    
        </table>
             <input style="float:left;" type="Submit" value="Complete Update"/>
        </form>
        <form action="http://daveproperties.comeze.com/homepage.php">
            <input type="Submit" value="Return to Homepage"/>
        </form>
    
           
        
    
</body>
</html>
<!--Joshua Moratalla-->