<?php
   include('Config.php');
   if(!isset($_SESSION)){
     session_start();
   }
   $user_check = $_SESSION['login_user'];
   
   $ses_sql = mysqli_query($db,"select user_id,username,Permission from Accounts where username = '$user_check' ") or die(mysqli_error($db));
   
   $row = mysqli_fetch_array($ses_sql);
   
   $login_session = $row['username'];
   
 ?>