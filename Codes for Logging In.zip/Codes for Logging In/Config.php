<?php
$servername = "localhost";
$username = "id1609331_dave1";
$password = "DaveProperties";
$database = "id1609331_houses";

$db = mysqli_connect($servername,$username,$password,$database);

?>