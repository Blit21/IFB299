<!DOCTYPE html>
<html>
<head>
<style>

ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    background-color: #789;
    position: fixed;
    height: 97%;
    overflow: auto;
    border: 1px solid #000; 
}

li a {
    display: block;
    color: #000;
    text-decoration: none;
	padding-top: 20px;
	padding-bottom: 20px;
}

li a:hover {
    background-color: #784;
    color: white;
}
    
li.AllNav {
    text-align: center;
    border-bottom: 1px solid #000;
    display: block;
    color: #000;
    text-decoration: none;
	width: 100;
}

li.AllNav:last-child {
    border-bottom: none;
}
	
.NavButtons{
	height:58px;
	background-color: #789;
}

.infobars{
	padding-top: 20px;
	padding-bottom: 20px;
}

.ProfilePicture{
	width:80px;
	height:75px; 
	border:1px solid black;
}

.InfoColumn{
    float:left;
    margin-left: 90px;
    width:550px;
}
    
.SearchArea{
    height:50px;
    padding: 10px;
}

.IndividualResult{
    border:1px solid black;
    min-width:820px;
    height:230px;
    margin-bottom: 10px;
}

.AdvertColumn{
    float: left;
    margin-left: 320px;
    max-width: 150px;
}

.picture{
    float:left;
    height:230px;
    width:300px;
}
ol{
    list-style-type: none;
}
    
.info{
    float:left; 
    text-align: left; 
    padding-left:10px;
    line-height: 80%;
}

.results{
        
}
    
tr{
    height:20px;  
}
    
    
</style>
    
</head>
    
<body bgcolor="#E6E6FA">
    
    <div class="Navigation">
        <ul>
            <li class="AllNav" style="padding:20px 20px;"><img   src="davidattenboroughface.jpg" class="ProfilePicture" ></li>
            <li class="AllNav infobars"> Dave/Admin:</li>
            <li class="AllNav" style="height:20px;background-color:#787"></li>
            
            <li class="AllNav NavButtons"><a href="file:///C:/Users/Joshua/Documents/Uni/ifb299/Website%20shit/Login%20Page.html">Sign Out</a></li>
            <li class="AllNav NavButtons"><a href="file:///C:/Users/Joshua/Documents/Uni/ifb299/Website%20shit/Daves%20Tenant%20Page.html">Tenants</a></li>
            <li class="AllNav NavButtons"><a href="file:///C:/Users/Joshua/Documents/Uni/ifb299/Website%20shit/Daves%20Page.html">Properties</a></li>
            <li class="AllNav NavButtons"><a href="file:///C:/Users/Joshua/Documents/Uni/ifb299/Website%20shit/Daves%20Contact%20Page.html">Contacts</a></li>
                
            <li class="AllNav" style="height:20px;background-color:#787"></li>
            <li >
                    <p style="text-align:left; padding-left:10px;"> 	 email:</p>
                    <p style="text-align:left; padding-left:10px;"> 	 address:</p>
            </li>
        </ul>
	</div>
    
    <div style="min-width:1000px;">
        <div class="InfoColumn">
              <div class="results" style="padding-top:10px;">
                <h2 style="margin-left:50px"> Properties</h2>
                <ol>
                    <li class="IndividualResult">
                        <img src="advertisement%20images.jpg"alt="advert image" 	class="picture">

                        <div class="info">
                            <table>
                                <col width="150px">
                                <col width="350px">

                                <tr>
                                    <td>Location:</td>
                                    <td>58 Washington Street,Coorparoo 4521</td>
                                </tr>
                                <tr>
                                    <td>Property Type:</td>
                                    <td>House</td>
                                </tr>
                                <tr>
                                    <td>Rent:</td>
                                    <td>$450/week</td>
                                </tr>
                                <tr>
                                    <td>Condition:</td>
                                    <td>Unfurnished</td>
                                </tr>
                                <tr>
                                    <td>Beds:</td>
                                    <td>5</td>
                                </tr>
                                <tr>
                                    <td>Bathroom:</td>
                                    <td>3</td>
                                </tr>
                                <tr>
                                    <td>Car Space:</td>
                                    <td>3</td>
                                </tr>
                                <tr>
                                    <td>House Tenant:</td>
                                    <td>Elizabeth Prowse</td>
                                </tr>
                                <tr>
                                    <td>Designated Staff:</td>
                                    <td>Jake Cassimatis</td>
                                </tr>
                            </table>
                            <input type="Submit" value="Edit Property"/>
                        </div>
                    </li>
                   
                    <li class="IndividualResult">
                        <img src="advertisement%20images.jpg"alt="advert image" 	class="picture">

                        <div class="info">
                            <table>
                                <col width="150px">
                                <col width="250px">

                                <tr>
                                    <td>Location:</td>
                                    <td>12 Queen Road ,Sunny Bank 4489</td>
                                </tr>
                                <tr>
                                    <td>Property Type:</td>
                                    <td>House</td>
                                </tr>
                                <tr>
                                    <td>Rent:</td>
                                    <td>$410/week</td>
                                </tr>
                                <tr>
                                    <td>Condition:</td>
                                    <td>Unfurnished</td>
                                </tr>
                                <tr>
                                    <td>Beds:</td>
                                    <td>4</td>
                                </tr>
                                <tr>
                                    <td>Bathroom:</td>
                                    <td>2</td>
                                </tr>
                                <tr>
                                    <td>Car Space:</td>
                                    <td>2</td>
                                </tr>
                                <tr>
                                    <td>House Tenant:</td>
                                    <td>None</td>
                                </tr>
                                <tr>
                                    <td>Designated Staff:</td>
                                    <td>Michael Wing</td>
                                </tr>
                            </table>
                            <input type="Submit" value="Edit Property"/>
                        </div>
                    </li>
                    
                    <li class="IndividualResult">
                        <img src="advertisement%20images.jpg"alt="advert image" 	class="picture">

                        <div class="info">
                            <table>
                                <col width="150px">
                                <col width="250px">

                                <tr>
                                    <td>Location:</td>
                                    <td>57 Martin Luther King Road,Carina 4152</td>
                                </tr>
                                <tr>
                                    <td>Property Type:</td>
                                    <td>Townhouse</td>
                                </tr>
                                <tr>
                                    <td>Rent:</td>
                                    <td>$390/week</td>
                                </tr>
                                <tr>
                                    <td>Condition:</td>
                                    <td>Unfurnished</td>
                                </tr>
                                <tr>
                                    <td>Beds:</td>
                                    <td>4</td>
                                </tr>
                                <tr>
                                    <td>Bathroom:</td>
                                    <td>3</td>
                                </tr>
                                <tr>
                                    <td>Car Space:</td>
                                    <td>2</td>
                                </tr>
                                <tr>
                                    <td>House Tenant:</td>
                                    <td>None</td>
                                </tr>
                                <tr>
                                    <td>Designated Staff:</td>
                                    <td>Amy Timber</td>
                                </tr>
                            </table>
                            <input type="Submit" value="Edit Property"/>
                        </div>
                    </li>
                    
                    <li class="IndividualResult">
                        <img src="advertisement%20images.jpg"alt="advert image" 	class="picture">

                        <div class="info">
                            <table>
                                <col width="150px">
                                <col width="250px">

                                <tr>
                                    <td>Location:</td>
                                    <td>2/92 Bovelles Street,Brooksville 5921</td>
                                </tr>
                                <tr>
                                    <td>Property Type:</td>
                                    <td>Apartment</td>
                                </tr>
                                <tr>
                                    <td>Rent:</td>
                                    <td>$350/week</td>
                                </tr>
                                <tr>
                                    <td>Condition:</td>
                                    <td>Furnished</td>
                                </tr>
                                <tr>
                                    <td>Beds:</td>
                                    <td>2</td>
                                </tr>
                                <tr>
                                    <td>Bathroom:</td>
                                    <td>1</td>
                                </tr>
                                <tr>
                                    <td>Car Space:</td>
                                    <td>1</td>
                                </tr>
                                <tr>
                                    <td>House Tenant:</td>
                                    <td>Brianna Weston</td>
                                </tr>
                                <tr>
                                    <td>Designated Staff:</td>
                                    <td>Abby Weber</td>
                                </tr>
                            </table>
                            <input type="Submit" value="Edit Property"/>
                        </div>
                    </li>
                    
                    <li class="IndividualResult">
                        <img src="advertisement%20images.jpg"alt="advert image" 	class="picture">

                        <div class="info">
                            <table>
                                <col width="150px">
                                <col width="250px">

                                <tr>
                                    <td>Location:</td>
                                    <td>68 Oakforge Lane, Logan 5214</td>
                                </tr>
                                <tr>
                                    <td>Property Type:</td>
                                    <td>House</td>
                                </tr>
                                <tr>
                                    <td>Rent:</td>
                                    <td>$550/week</td>
                                </tr>
                                <tr>
                                    <td>Condition:</td>
                                    <td>Unfurnished</td>
                                </tr>
                                <tr>
                                    <td>Beds:</td>
                                    <td>4</td>
                                </tr>
                                <tr>
                                    <td>Bathroom:</td>
                                    <td>2</td>
                                </tr>
                                <tr>
                                    <td>Car Space:</td>
                                    <td>2</td>
                                </tr>
                                <tr>
                                    <td>House Tenant:</td>
                                    <td>Logan Marian</td>
                                </tr>
                                <tr>
                                    <td>Designated Staff:</td>
                                    <td>Beavis Cornholio</td>
                                </tr>
                            </table>
                            <input type="Submit" value="Edit Property"/>
                        </div>
                    </li>
                    
                </ol>

              </div>
        </div>
    
        <div class ="AdvertColumn" style="border:1px solid black;">
                <h3 style="text-align:center;">Ads</h3>
                <img src="advertisement%20images.jpg"alt="advert image" style="width:150px;height:115px">
                <img src="advertisement%20images.jpg"alt="advert image" style="width:150px;height:115px">
                <img src="advertisement%20images.jpg"alt="advert image" style="width:150px;height:115px">
        </div>
    </div>
    
</body>
</html>

<!--Joshua Moratalla-->

<!--Joshua Moratalla "table the contact info"-->