<?php
$servername = "localhost";
$username = "id1609331_accounts";
$password = "DaveProperties";
$database = "id1609331_accounts";

$db = mysqli_connect($servername,$username,$password,$database);

?>