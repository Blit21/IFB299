<?php
   include("Config.php");
   session_start();
   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
      // username and password sent from form 
      
      $username = mysqli_real_escape_string($db,$_POST['username']);
      $password = mysqli_real_escape_string($db,$_POST['password']); 
      
      $sql = "SELECT user_id FROM Accounts WHERE Username = '$username' and Password = '$password'";
      $result = mysqli_query($db,$sql) or die(mysqli_error($db));
      $row = mysqli_fetch_array($result);
      
      if($result){
        $count = mysqli_num_rows($result);
		
        if($count == 1) {
            $_SESSION['login_user'] = $username;
         
            header("Location: http://daveproperties.comeze.com/Tenant%20homepage.php");
            exit();
        }else {
            echo"Your Login Name or Password is invalid";
        }
      }else{
        die(mysql_error());
      }
       
        
   }
?>

<!DOCTYPE html>
<html>
<head>
<style>

.positioning{
    position:absolute;
    left: 50%;
    top: 50%;
    border:1px solid black;
    max-width: 250px;
    min-height: 50px;
}

.Userinput{
    float:left;
}

.GroupBoxes{
    float:left;
    min-width:250px; 
    min-height:30px;
    border:1px solid black;
}

.InputText{
    float:left;
    width:75px;
}

</style>
</head>
<body bgcolor="#E6E6FA">


<div class="positioning">
    <div class="GroupBoxes">
        <form action="" method="POST"> 
            <p>
                <label class="InputText"> Username :</label>
                <input class="UserInput" type="username" id="username" name="username" placeholder="Enter Username here..."/>
            </p>
            <p>
                <label class="InputText"> Password:</label>
                <input type="password" id="password" name="password" placeholder="Enter Password here..."/>
            </p>
            <input type="Submit" value="Login"/>
        </form>
        
    </div>
    
    
            
        
</div>

</body>
</html> 

<!--Joshua Moratalla-->