<?php
   include('session.php');
?>

<!DOCTYPE html>
<html>
<head>
<style>

ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
    background-color: #789;
    position: fixed;
    height: 97%;
    border: 1px solid #000; 
    overflow: auto;
}

li a {
    display: block;
    color: #000;
    text-decoration: none;
}

li a:hover {
    background-color: #784;
    color: white;
}
    
li {
    text-align: center;
    border-bottom: 1px solid #000;
    display: block;
    color: #000;
    text-decoration: none;
	max-width: 120px;
}


.NavButtons{
	height:58px;
	background-color: #789;
}

.NavButtonLink{
    padding-top: 20px;
	padding-bottom: 20px;
}

.infobars{
	padding-top: 20px;
	padding-bottom: 20px;
}

.ProfilePicture{
	width:80px;
	height:75px; 
	border:1px solid black;
}

.MainColumn{
    float:left;
    margin-left: 140px;
    width:550px;
    padding:10px;
}

.SearchArea{
    height:0px;
    padding: 10px;
}
    
.IndividualResult{
    border:1px solid black;
    min-width:500px;
    height:150px;
    margin-bottom: 10px;
}

.Advertisements{
    float: left;
    margin-left:20px;
}

.SearchPicture{
    float:left;
    width:220px;
    height:175px;
    border:1px solid black;    
}
    
.info{
    float:left; 
    text-align: left; 
    padding-left:10px;
}

.results{
    margin-top: 20px;
}

.picture{
    float:left;
    height:150px;
}
</style>
</head>
    
<body bgcolor="#E6E6FA">
    
    <div class="Navigation">
        <ul>
            <li style="padding:20px 20px;">
                <img src="davidattenboroughface.jpg" class="ProfilePicture">
                <a href="file:///C:/Users/Joshua/Documents/Uni/ifb299/Website%20shit/TenantProfile.html" style="height:15px;border:1px solid black; padding-bottom:3px;">Edit Profile</a>
            </li>
            
            <li class="infobars"> Tenant ID: EProwse123</li>
            <li class="infobars">Current Lease: #1</li>
            <li style="height:20px;background-color:#787"></li>
            
            <li class="NavButtons"><a class="NavButtonLink" href="file:///C:/Users/Joshua/Documents/Uni/ifb299/Website%20shit/Login%20Page.html">Sign Out</a></li>
            <li class="NavButtons"><a class="NavButtonLink" href="file:///C:/Users/Joshua/Documents/Uni/ifb299/Website%20shit/Homepage%20draft.html">Homepage</a></li>
            
            <li class="NavButtons"><a class="NavButtonLink" href="file:///C:/Users/Joshua/Documents/Uni/ifb299/Website%20shit/Contacts.html">Staff</a></li>
            
            <li style="height:20px;background-color:#787"></li>
            <li >
                <p style="text-align:left; padding-left:10px;"> 	 email:</p>
                <p style="text-align:left; padding-left:10px;"> 	 address:</p>
            </li>
        </ul>
    </div>
    
    <img src="house-for-rent.jpg" alt="homepage image" style="border:1px solid black;margin-left:140px;width:750px;height:500px">
    
    
    <div class="MainColumn" style="border:1px solid black;min-width:600px;max-width:700px;">
        <div style="min-width:700">
            <h2 style="margin-left:20px;">Search for a Home</h2>
            <div class="SearchArea" style="border:1px solid black; height:25px;">
                <input type="text" name="search" placeholder="Enter keywords here..." style="float:left;"/>
                <input type="submit" value="Search here" style="float:left;"/>
                <p style="float:left;margin-left:10px;position:relative; bottom:15px"> Filter:</p>
                <select style="float:left; margin-left:5px">
                    <option >None</option>
                    <option >Suburb</option>
                    <option >Cost</option>
                    <option >Owner</option>
                    <option >Staff</option>
                </select>
            </div>
        
        <div class="results">
            <ol>
                    <li class="IndividualResult">
                        <img src="advertisement%20images.jpg"alt="advert image" 	class="picture">

                        <div class="info">
                            <table>
                                <col width="75px">
                                <col width="150px">

                                <tr>
                                    <td>Location:</td>
                                    <td>Somewhere</td>
                                </tr>
                                <tr>
                                    <td>Cost:</td>
                                    <td>Alot</td>
                                </tr>
                                <tr>
                                    <td>Condition:</td>
                                    <td>Alright</td>
                                </tr>
                                <tr>
                                    <td>Occupied:</td>
                                    <td>Maybe</td>
                                </tr>
                            </table>
                            <input type="Submit" value="Edit Property"/>
                        </div>
                    </li>
                    <li class="IndividualResult">
                        <img src="advertisement%20images.jpg"alt="advert image" 	class="picture">

                        <div class="info">
                            <table>
                                <col width="75px">
                                <col width="180px">

                                <tr>
                                    <td>Location:</td>
                                    <td>Somewhere</td>
                                </tr>
                                <tr>
                                    <td>Cost:</td>
                                    <td>Alot</td>
                                </tr>
                                <tr>
                                    <td>Condition:</td>
                                    <td>Alright</td>
                                </tr>
                                <tr>
                                    <td>Occupied:</td>
                                    <td>Maybe</td>
                                </tr>
                            </table>
                            <input type="Submit" value="Edit Property"/>
                        </div>
                    </li>
                    <li class="IndividualResult">
                        <img src="advertisement%20images.jpg"alt="advert image" 	class="picture">

                        <div class="info">
                            <table>
                                <col width="75px">
                                <col width="180px">

                                <tr>
                                    <td>Location:</td>
                                    <td>Somewhere</td>
                                </tr>
                                <tr>
                                    <td>Cost:</td>
                                    <td>Alot</td>
                                </tr>
                                <tr>
                                    <td>Condition:</td>
                                    <td>Alright</td>
                                </tr>
                                <tr>
                                    <td>Occupied:</td>
                                    <td>Maybe</td>
                                </tr>
                            </table>
                            <input type="Submit" value="Edit Property"/>
                        </div>
                    </li>
                </ol>

        </div>
    </div>
        

        <div class ="Advertisements" style="">
           <img src="advertisement%20images.jpg"alt="advert image" 	style="border:1px solid black;width:150px;height:115px">
        </div> 
    </div
    
</body>
</html>

<!--Joshua Moratalla-->