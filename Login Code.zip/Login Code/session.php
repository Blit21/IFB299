<?php
   include('Config.php');
   session_start();
   
   $user_check = $_SESSION['login_user'];
   
   $sessionresult = mysqli_query($db,"select username from Accounts where username = '$user_check' ") or die (mysqli_error($db));
   
   $row = mysqli_fetch_array($sessionresult);
   
   $login_session = $row['username'];
   
   if(!isset($_SESSION['login_user'])){
      header("Location:http://daveproperties.comeze.com/Tenant%20homepage.php");
   }
?>