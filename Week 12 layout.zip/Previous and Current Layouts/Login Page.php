<?php
$servername = "localhost:3306";
$username = "username";
$password = "password";

// Create connection
$conn = mysqli_connect($servername, $username, $password);

// Check connection
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}
echo "Connected successfully";
?>

<!DOCTYPE html>
<html>
<head>
<style>

.positioning{
    position:absolute;
    left: 50%;
    top: 50%;
    border:1px solid black;
    max-width: 250px;
    min-height: 50px;
}

.Userinput{
    float:left;
}

.GroupBoxes{
    float:left;
    min-width:250px; 
    min-height:30px;
    border:1px solid black;
}

.InputText{
    float:left;
    width:75px;
}

</style>
</head>
<body bgcolor="#E6E6FA">


<div class="positioning">
    <div class="GroupBoxes">
        <form action="Login.php" method="post"> 
            <p>
                <label class="InputText"> Username :</label>
                <input class="UserInput" type="username" name="username" placeholder="Enter Username here..."/>
            </p>
            <p>
                <label class="InputText"> Password:</label>
                <input type="password" name="password" placeholder="Enter Password here..."/>
            </p>
            <input type="Submit" value="Login"/>
        </form>
        
    </div>
    
    
            
        
</div>

</body>
</html> 

<!--Joshua Moratalla-->