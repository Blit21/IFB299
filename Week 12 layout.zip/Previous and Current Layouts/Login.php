<?php
    $username = $_post ['username'];
    $password = $_post ['password'];
    
    $username = stripcslashes($username);
    $password = stripcslashes($password);
    $username = mysql_real_escape_string($username);
    $password = mysql_real_escape_string($password);
    
    mysql_connect("localhost:3306","DaveProperties","Pickles123")
    mysql_select_db("Accounts");
    
    $result = mysql_query("select * from users where username= '$username' and password = '$password'")
        or die("Failed to query database".mysqlerror());
    
    $row =mysql_fetch_array($result);

    if($row['$username']==$username && $row['$password']==$password&& ("" !== $username || "" !== $password))){
        echo "Login Successful";
    }else{
        echo"Login Failed";
    }
?>  
