<?php
   include("Config.php");
   session_start();
   
   if($_SERVER["REQUEST_METHOD"] == "POST") {
      // username and password sent from form 
      
      $username = mysqli_real_escape_string($db,$_POST['username']);
      $password = mysqli_real_escape_string($db,$_POST['password']); 
      
      $sql = "SELECT id FROM admin WHERE Username = '$username' and Password = '$password'";
      $result = mysqli_query($db,$sql) or die(mysqli_error($db));
      $row = mysqli_fetch_array($result);
      $active = $row['active'];
      
      if($result){
        $count = mysqli_num_rows($result);
      
        // If result matched $myusername and $mypassword, table row must be 1 row
		
        if($count == 1) {
            session_register("username");
            $_SESSION['login_user'] = $username;
         
            header("Location: ttp://daveproperties.comeze.com/Tenant%20homepage.php");
        }else {
            $error = "Your Login Name or Password is invalid";
        }
      }else{
        die(mysql_error());
      }
       
        
   }
?>




