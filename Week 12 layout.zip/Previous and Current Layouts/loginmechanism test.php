<?php
    session_start();
    $username = $_POST['username'];
    $password = $_POST['password'];

    $link=mysqli_connect("localhost", "id1609331_accounts", "DaveProperties", "id1609331_accounts") or die($link);

    $username = stripcslashes($username);
    $password = stripcslashes($password);
    $username = mysqli_real_escape_string($link,$username);
    $password = mysqli_real_escape_string($link,$password);
    
    $query = "SELECT * FROM Accounts WHERE username = '$username' AND password = SHA('$password')";
    $result = mysqli_query($link,$query);
    
    $count= mysqli_num_rows($result);
    if ($count==1){
          echo " $action works";
          if($result==1){
               $row=mysqli_fetch_assoc($action);
               $_SESSION['username'] = $row['username'];
               $_SESSION['password'] = $row['password'];

              header('Location: http://daveproperties.comeze.com/Tenant%20homepage.php');
              exit();
          }
    }
    echo "not complete";
   
?>

<?php
    session_start();
    $username = $_POST['username'];
    $password = $_POST['password'];

    $link=mysqli_connect("localhost", "id1609331_accounts", "DaveProperties", "id1609331_accounts") or die($link);

    $username = stripcslashes($username);
    $password = stripcslashes($password);
    $username = mysqli_real_escape_string($link,$username);
    $password = mysqli_real_escape_string($link,$password);
    
    $query = "SELECT * FROM Accounts WHERE username = '$username' AND password = SHA('$password')";
    $action = mysqli_query($link,$query);

    if ($action){
          echo " $action works";
          if($result=mysqli_num_rows($action)&& $result=1){
               $row=mysqli_fetch_assoc($action);
               $_SESSION['username'] = $row['username'];
               $_SESSION['password'] = $row['password'];

              header('Location: http://daveproperties.comeze.com/Tenant%20homepage.php');
              exit();
          }
    }
    echo "not complete";
   
?>